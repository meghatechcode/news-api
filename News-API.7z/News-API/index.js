const express = require("express");
const app = express();
const PORT = 3000;

// Dummy news data
const news = [
  {
    title: "AI is Transforming Industries",
    image: "https://images.unsplash.com/photo-1581091215367-7b6c5e3bdb96",
    description: "Artificial Intelligence is reshaping various fields worldwide."
  },
  {
    title: "SpaceX Launch Successful",
    image: "https://via.placeholder.com/150",
    description: "SpaceX has successfully launched its new rocket into orbit."
  },
  {
    title: "Global Economy Update",
    image: "https://via.placeholder.com/150",
    description: "Markets are stabilizing after recent fluctuations."
  },
  {
    title: "New Tech in Smartphones",
    image: "https://via.placeholder.com/150",
    description: "Latest smartphones feature advanced AI-driven cameras."
  },
  {
    title: "Climate Change Conference",
    image: "https://via.placeholder.com/150",
    description: "World leaders meet to discuss solutions for climate change."
  }
];

// API route
app.get("/news", (req, res) => {
  res.json(news);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
